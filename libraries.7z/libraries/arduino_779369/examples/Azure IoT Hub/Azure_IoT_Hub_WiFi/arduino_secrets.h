// Fill in  your WiFi networks SSID and password
#define SECRET_SSID      ""
#define SECRET_PASS      ""

// Fill in the hostname of your Azure IoT Hub broker
#define SECRET_BROKER    "<hub name>.azure-devices.net"

// Fill in the device id
#define SECRET_DEVICE_ID "<device id>"
