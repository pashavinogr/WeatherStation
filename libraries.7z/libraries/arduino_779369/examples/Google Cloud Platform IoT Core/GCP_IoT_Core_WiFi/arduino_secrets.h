// Fill in your WiFi networks SSID and password
#define SECRET_SSID         ""
#define SECRET_PASS         ""

// Fill in your Google Cloud Platform - IoT Core info
#define SECRET_PROJECT_ID   ""
#define SECRET_CLOUD_REGION ""
#define SECRET_REGISTRY_ID  ""
#define SECRET_DEVICE_ID    ""
